package lesson2.labsolns.prob2C;

import java.util.*;

public class Student {
	List<Section> sectionsEnrolledIn;
	String name;
	
	Student(String name) {
		sectionsEnrolledIn = new ArrayList<Section>();
		this.name = name;
	}
	
	public void addSection(Section s) {
		sectionsEnrolledIn.add(s);
	}
	
	public String toString() {
		return "Student: Sections: " + sectionsEnrolledIn;
	}
}
