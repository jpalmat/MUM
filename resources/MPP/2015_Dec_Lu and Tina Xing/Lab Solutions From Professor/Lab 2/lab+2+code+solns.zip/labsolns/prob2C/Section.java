package lesson2.labsolns.prob2C;

import java.util.*;

public class Section {
	int sectionNumber;
	List<Student> enrolledStudents;
	
	public Section(int sectionNum) {
		this.sectionNumber = sectionNum;
		enrolledStudents = new ArrayList<>();
	}
	public void addStudent(Student st) {
		enrolledStudents.add(st);
	}
	/*
	public String toString() {
		return "Section: enrolled students: " + enrolledStudents;
	}*/
	public String toString() {
		return "Section number: " + sectionNumber;
	}
	
}
