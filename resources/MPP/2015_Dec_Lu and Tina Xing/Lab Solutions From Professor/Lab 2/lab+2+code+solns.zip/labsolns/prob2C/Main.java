package lesson2.labsolns.prob2C;

public class Main {

	public static void main(String[] args) {
		Section sect1 = new Section(101);
		Student st1 = new Student("Jim");
		st1.addSection(sect1);
		sect1.addStudent(st1);
		System.out.println(st1);
	}

}
