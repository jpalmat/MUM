package lesson2.labsolns.prob2A_externally_owned.otherpackage;
import java.util.*;

import lesson2.labsolns.prob2A_externally_owned.*;


public class Main {

	public static void main(String[] args) {
		Collection<DataRecord> data = Database.h.values();
		List<GradeReport> reports = new ArrayList<>();
		for(DataRecord d : data) {
			GradeReport g = new GradeReport(d.getGrade());
			Student st = new Student(d.getName(), g);
			g.setStudent(st);
			reports.add(g);
			
		}
		
		Collections.sort(reports);
		Iterator<GradeReport> it = reports.iterator();
		System.out.println("A Students:");
		GradeReport next = null;
		while((next =it.next()) != null && next.getGrade().equals("A")) {
			System.out.print(next.getStudent().getName() + " ");
		}
		
		

	}

}
