package lesson2.labsolns.prob2A_externally_owned;



public class Student {
	private GradeReport report;
	private String name;
	public Student(String nm, GradeReport report) {
		name = nm;
		this.report = report;
		
	}
	public String getName() {
		return name;
	}
	public GradeReport getReport() {
		return report;
	}
}
