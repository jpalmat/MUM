package lesson2.labsolns.prob2A_student_owned.otherpackage;
import java.util.*;

import lesson2.labsolns.prob2A_student_owned.GradeReport;
import lesson2.labsolns.prob2A_student_owned.Student;
public class Main {

	public static void main(String[] args) {
		Student st1 = new Student("Bob");
		st1.getReport().setGrade("A");
		Student st2 = new Student("Alan");
		st2.getReport().setGrade("B");
		Student st3 = new Student("Dave");
		st3.getReport().setGrade("A");
		Student st4 = new Student("Perry");
		st4.getReport().setGrade("C");
		List<Student> students = Arrays.asList(st1, st2, st3, st4);
		List<GradeReport> reports = new ArrayList<>();
		for(Student s: students) {
			reports.add(s.getReport());
		}
		Collections.sort(reports);
		Iterator<GradeReport> it = reports.iterator();
		System.out.println("A Students:");
		GradeReport next = null;
		while((next =it.next()) != null && next.getGrade().equals("A")) {
			System.out.print(next.getStudent().getName() + " ");
		}
		//no way to create a GradeReport first, and pass in a student
		

	}

}
