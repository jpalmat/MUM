package lesson10.labsolns.prob6;

public enum Gender {
	M, F
}
