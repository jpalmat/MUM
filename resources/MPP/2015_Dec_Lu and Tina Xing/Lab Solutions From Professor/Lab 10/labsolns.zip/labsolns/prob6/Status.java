package lesson10.labsolns.prob6;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
