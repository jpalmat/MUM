package lesson3.labsolns.prob1inheritance;

public class PersonWithJob extends Person {

	private double salary;

	public double getSalary() {
		return salary;
	}
	PersonWithJob(String n, double s) {
		super(n);
		salary = s;
	}

	@Override
	public boolean equals(Object aPerson) {
		if(aPerson == null) return false;
		if(!(aPerson instanceof PersonWithJob)) return false;
		PersonWithJob p = (PersonWithJob)aPerson;
		boolean isEqual = this.getName().equals(p.getName()) &&
				this.getSalary()==p.getSalary();
		return isEqual;
	}
	public static void main(String[] args) {
		Person pj1 = new PersonWithJob("Joe", 30000);
		Person pj2 = new PersonWithJob("Joe", 30000);
		Person p1 = new Person("Joe");
		Person p2 = new Person("Joe");
		//As PersonsWithJobs, pj1 should be equal to pj2
		System.out.println("pj1.equals(pj2)? " + pj1.equals(pj2));
		System.out.println("pj2.equals(pj1)? " + pj2.equals(pj1));
		//As Person, p1 should be equal to p2
		System.out.println("p1.equals(p2)? " + p1.equals(p2));
		System.out.println("p2.equals(p1)? " + p2.equals(p1));
		//As Person is not PersonWithJob, pj1 should NOT be equal to p1
		System.out.println("pj1.equals(p1)? " + pj1.equals(p1));
		System.out.println("p1.equals(pj1)? " + p1.equals(pj1));
	}


}
