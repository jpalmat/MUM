package lesson7.labsolns.prob3_staticstorage;

public enum StorageKey {
	LOGGED_IN;
}
