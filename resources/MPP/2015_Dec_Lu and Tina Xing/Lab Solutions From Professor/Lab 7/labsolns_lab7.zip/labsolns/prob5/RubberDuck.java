package lesson7.labsolns.prob5;

public class RubberDuck extends Duck implements Unquackable {
	
	@Override
	public void display() {
		System.out.println("  displaying");
		
	}
}
