package lesson7.labsolns.prob5;

public class MallardDuck extends Duck implements Flyable, Quackable {
	
	@Override
	public void display() {
		System.out.println("  display");
		
	}

}
