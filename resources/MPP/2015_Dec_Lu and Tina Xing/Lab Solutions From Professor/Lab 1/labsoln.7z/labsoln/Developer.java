package lesson1.labsoln;

import java.util.List;

public class Developer {
	private String developerId;
	private List<Feature> assignedFeatures;
}
