package lesson1.labsoln;
import java.util.*;
public class Release {
	private List<Sprint> sprintList;
}
