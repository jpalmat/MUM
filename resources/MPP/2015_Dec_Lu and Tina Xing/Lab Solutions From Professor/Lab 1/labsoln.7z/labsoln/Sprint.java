package lesson1.labsoln;

import java.time.LocalDate;
import java.util.List;

public class Sprint {
	private LocalDate dueDate;
	private List<Feature> sprintFeatures;
}
