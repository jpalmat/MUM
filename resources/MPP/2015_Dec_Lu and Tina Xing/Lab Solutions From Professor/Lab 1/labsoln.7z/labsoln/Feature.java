package lesson1.labsoln;

public class Feature {
	int hourRequired;
	int percentageRemaining;

}
