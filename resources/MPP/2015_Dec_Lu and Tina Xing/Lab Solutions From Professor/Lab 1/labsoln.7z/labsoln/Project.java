package lesson1.labsoln;
import java.util.*;
public class Project {
	private String projectId;
	private List<Feature> backlogFeatureList;
	private List<Release> releaseList;

}
