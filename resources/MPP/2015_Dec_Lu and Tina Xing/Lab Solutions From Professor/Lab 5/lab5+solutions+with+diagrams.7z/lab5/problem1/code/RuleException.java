//package lesson5.lecture.factorymethods2;

@SuppressWarnings("serial")
public class RuleException extends Exception {
	public RuleException() {
		super();
	}
	public RuleException(String msg) {
		super(msg);
	}
}
