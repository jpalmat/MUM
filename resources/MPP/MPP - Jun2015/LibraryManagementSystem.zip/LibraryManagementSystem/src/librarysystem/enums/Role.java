package librarysystem.enums;

import java.io.Serializable;

public enum Role implements Serializable {
	LIBRARIAN, ADMIN, BOTH;
}