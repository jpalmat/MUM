package com.fekadu.bookreview.controller;

import com.fekadu.bookreview.domain.Category;
import com.fekadu.bookreview.service.CategoryServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/categoryrest")
public class CategoryRestController {

    @Autowired
    CategoryServiceImpl categoryService;

    @PostMapping("/add")
    public List<Category> createCategory(@Valid @RequestBody Category category) {
         categoryService.save(category);
         return categoryService.getAll();
    }
}
