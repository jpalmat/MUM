package com.fekadu.bookreview.controller;

import com.fekadu.bookreview.domain.Category;
import com.fekadu.bookreview.service.CategoryServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    CategoryServiceImpl categoryService;

    private void addCategories() {
        Category category1 = new Category();
        category1.setName("Novel");
        categoryService.save(category1);

        Category category2 = new Category();
        category2.setName("Autobiography");
        categoryService.save(category2);
    }

    @RequestMapping(value = {"/", "/add"}, method = RequestMethod.GET)
    public String getCategoryForm(@ModelAttribute("category") Category category, Model model) {

        //addCategories();

        model.addAttribute("categories", categoryService.getAll());
        return "categoryForm";
    }

    @PostMapping("/add")
    public String saveCategory(@ModelAttribute("category") Category category) {
        categoryService.save(category);

        return "redirect:/category/add";
    }

    @GetMapping("/withajax")
    public String getCategoryFormWithAjax(Model model){
        model.addAttribute("categories", categoryService.getAll());
        return "categoryFormAjax";
    }
}
