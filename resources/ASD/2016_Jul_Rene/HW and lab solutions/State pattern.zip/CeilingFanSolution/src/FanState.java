
public interface FanState {
   void pullred();
   void pullgreen();
}
