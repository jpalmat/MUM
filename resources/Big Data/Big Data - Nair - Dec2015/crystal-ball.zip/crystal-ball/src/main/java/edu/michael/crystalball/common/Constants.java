package edu.michael.crystalball.common;

public class Constants {
	
	//public final static String 

}
