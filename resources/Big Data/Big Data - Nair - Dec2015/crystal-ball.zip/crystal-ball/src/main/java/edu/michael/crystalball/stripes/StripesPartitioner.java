package edu.michael.crystalball.stripes;

public class StripesPartitioner {

}
