package edu.michael.crystalball.hybrid;

public class HybridPartitioner {

}
