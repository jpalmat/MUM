package edu.michael.crystalball.pairs;

public class Partitioner {

}
