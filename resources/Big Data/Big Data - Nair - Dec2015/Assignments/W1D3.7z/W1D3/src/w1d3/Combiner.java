/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1d3;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author 984790
 */
public class Combiner {
    public Map<String,Integer> Combine(Map<String,Integer> input){
        Map<String,Integer> result = new HashMap<String, Integer>();
        
        for(String s : input.keySet()){
            if(result.containsKey(s)){
                int value = result.get(s)+1;
                System.out.println(value);
                result.remove(s);
                result.put(s, value);
            }
            else
                result.put(s, 1);
        }
        System.out.println(result);
        return result;
    }
}
