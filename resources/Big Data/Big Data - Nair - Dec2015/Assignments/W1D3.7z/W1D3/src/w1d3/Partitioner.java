/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1d3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author 984790
 */
public class Partitioner {
    
    public int LessThanK = 1;
    public int LessThanP = 2;
    public int MoreThanP = 3;
    
    public Map<Integer, List<String>> Partition(Map<String, Integer> input){
        Map<Integer, List<String>> result= new HashMap<Integer, List<String>>();
        result.put(LessThanK, new ArrayList());
        result.put(LessThanP, new ArrayList());
        result.put(MoreThanP, new ArrayList());
        
        for(String s : input.keySet()){
            if(s.charAt(0)< 'k' && !result.containsKey(s)){
                List<String> values = result.get(LessThanK);
                values.add(s);
                result.replace(LessThanK, values);
            }
            else if(s.charAt(0)< 'p' && !result.containsKey(s)){
                  List<String> values = result.get(LessThanP);
                values.add(s);
                result.replace(LessThanP, values);
            }
            else{
                  List<String> values = result.get(MoreThanP);
                values.add(s);
                result.replace(MoreThanP, values);
            }  
        }
        return result;
    }
}
