/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1d3;

import java.util.List;
import java.util.Map;

/**
 *
 * @author 984790
 */
public class MyCounter {
    public int CountTraffic(Map<String,Integer> input, List<String> partition){
        int traffic = 0;
        for(String s : input.keySet()){
            if(!partition.contains(s))           
                traffic+=input.get(s);
        }
        return traffic;
    }
}
