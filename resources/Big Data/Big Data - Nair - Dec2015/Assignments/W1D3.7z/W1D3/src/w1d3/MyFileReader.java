/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1d3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author 984790
 */
public class MyFileReader {
    
    public String readFile(String path){
        String line;
        String text = "";
        
        File file = new File(path);
        FileReader fr = null;
        try
        {
            fr = new FileReader(file);
        } 
        catch (FileNotFoundException e) 
        {  
            System.out.println( "File doesn't exists" );
            e.printStackTrace();
        }
        BufferedReader br = new BufferedReader(fr);
        
        try
        {
            while((line = br.readLine()) != null)
            {
                text += line;
            }
        }catch(Exception e){

        }
        return text;
    }
    public Map<String ,Integer> findTerms(String input){
      
        Map<String ,Integer> result = new HashMap<String ,Integer>();
        String[] terms  = input.split(" ");
        for(String s: terms){
            result.put(s, 1);
        }
          
        return result;
    }
}
