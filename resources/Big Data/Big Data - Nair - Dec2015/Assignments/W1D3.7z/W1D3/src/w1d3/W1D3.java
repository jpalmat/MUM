/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1d3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author 984790
 */
public class W1D3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<String> files = new ArrayList<String>();
        files.add("file1.txt");
        files.add("file2.txt");
        files.add("file3.txt");
        
        int TrafficWithoutCompiner = 0;
        int TrafficWithCompiner = 0;
        
        int PartitionIndex = 1;
        
        for(String s: files){
            MyFileReader reader = new MyFileReader();
            Map<String ,Integer> terms = reader.findTerms(reader.readFile(s));
            Partitioner p = new Partitioner();
             Map<Integer, List<String>> partitions = p.Partition(terms);
             
             MyCounter c = new MyCounter();
            TrafficWithoutCompiner+= c.CountTraffic(terms, partitions.get(PartitionIndex++));
        } 
        
        System.out.println(TrafficWithoutCompiner);
        
        
         PartitionIndex = 1;
        for(String s: files){
            MyFileReader reader = new MyFileReader();
            Map<String ,Integer> terms = reader.findTerms(reader.readFile(s));
            Partitioner p = new Partitioner();
             Map<Integer, List<String>> partitions = p.Partition(terms);
            TrafficWithCompiner+= new MyCounter().CountTraffic(new Combiner().Combine(terms), partitions.get(PartitionIndex++));
        } 
        
        System.out.println(TrafficWithCompiner);
       
        
    }
    
}
