package spark.racerlaps;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

import java.util.Arrays;
import java.util.regex.Pattern;

public class BestTime {
	private static final Pattern SPACE = Pattern.compile(" ");
	
	
  private static final FlatMapFunction<String, String> LAPS =
      new FlatMapFunction<String, String>() {
        @Override
        public Iterable<String> call(String s) throws Exception {
          return Arrays.asList(SPACE.split(s));
        }
      };

  private static final PairFunction<String, String, Integer> RACER =
      new PairFunction<String, String, Integer>() {
        @Override
        public Tuple2<String, Integer> call(String s) throws Exception {
        	String[] racerData = s.split(",");
        	return new Tuple2<String, Integer>(racerData[0], Integer.parseInt(racerData[1]));
        }
      };

  private static final Function2<Integer, Integer, Integer> MIN =
      new Function2<Integer, Integer, Integer>() {
        @Override
        public Integer call(Integer a, Integer b) throws Exception {
          return (a < b) ? a : b;
        }
      };

  public static void main(String[] args) {
    if (args.length < 1) {
      System.err.println("Please provide the input file full path as argument");
      System.exit(0);
    }

    SparkConf conf = new SparkConf().setAppName("example.spark.RacerBest").setMaster("local");
    JavaSparkContext context = new JavaSparkContext(conf);

    JavaRDD<String> file = context.textFile(args[0]);
    JavaRDD<String> laps = file.flatMap(LAPS);
    JavaPairRDD<String, Integer> racers = laps.mapToPair(RACER);
    JavaPairRDD<String, Integer> bestTimes = racers.reduceByKey(MIN);

    bestTimes.saveAsTextFile(args[1]);
  }
}
