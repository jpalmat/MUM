import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.compress.Compression.Algorithm;
import org.apache.hadoop.hbase.util.Bytes;

public class MyFirstHbaseTable {

	private static final String TABLE_NAME = "user";
	private static final String CF_DEFAULT = "personal_details";

	public static void main(String... args) throws IOException {

		Configuration config = HBaseConfiguration.create();
		
		try (Connection connection = ConnectionFactory.createConnection(config);
				Admin admin = connection.getAdmin()) {
			
			// CREATE TABLE 
			HTableDescriptor table = new HTableDescriptor(
					TableName.valueOf(TABLE_NAME));
			
			
					
			// CREATE FAMILY ("PERSONAL DATA")
			table.addFamily(new HColumnDescriptor(CF_DEFAULT)
					.setCompressionType(Algorithm.NONE));
			
			// CREATE FAMILY ("ROF DETAILS")
			table.addFamily(new HColumnDescriptor("prof_details"));
			
		     
			
			System.out.print("Creating table.... ");

			if (admin.tableExists(table.getTableName())) {
				admin.disableTable(table.getTableName());
				admin.deleteTable(table.getTableName());
			}
			admin.createTable(table);

			 HTable hTable = new HTable(config, "user");

				
				// PUT SOME DATA
				Put p = new Put(Bytes.toBytes("row1"));
				Put p2 = new Put(Bytes.toBytes("row2"));
				Put p3 = new Put(Bytes.toBytes("row3"));
				// adding values using add() method
			      
				// accepts column family name, qualifier/row name ,value
			      p.add(Bytes.toBytes("personal_details"),
			      Bytes.toBytes("name"),Bytes.toBytes("John"));

			      p.add(Bytes.toBytes("personal_details"),
			      Bytes.toBytes("city"),Bytes.toBytes("Boston"));

			      p.add(Bytes.toBytes("prof_details"),Bytes.toBytes("designation"),
			      Bytes.toBytes("Manager"));

			      p.add(Bytes.toBytes("prof_details"),Bytes.toBytes("salary"),
			      Bytes.toBytes("15000"));
			      
			      // Saving the put Instance to the HTable.
			     hTable.put(p);
			     
			      
			      
			      
			   // accepts column family name, qualifier/row name ,value
			      p2.add(Bytes.toBytes("personal_details"),
			      Bytes.toBytes("name"),Bytes.toBytes("Mary"));

			      p2.add(Bytes.toBytes("personal_details"),
			      Bytes.toBytes("city"),Bytes.toBytes("N Y"));

			      p2.add(Bytes.toBytes("prof_details"),Bytes.toBytes("designation"),
			      Bytes.toBytes("Software Engineer"));

			      p2.add(Bytes.toBytes("prof_details"),Bytes.toBytes("salary"),
			      Bytes.toBytes("130000"));
			      
			      // Saving the put Instance to the HTable.
			     hTable.put(p2);
			     
			      
			      
			   // accepts column family name, qualifier/row name ,value
			      p3.add(Bytes.toBytes("personal_details"),
			      Bytes.toBytes("name"),Bytes.toBytes("Bob"));

			      p3.add(Bytes.toBytes("personal_details"),
			      Bytes.toBytes("city"),Bytes.toBytes("N Y"));

			      p3.add(Bytes.toBytes("prof_details"),Bytes.toBytes("designation"),
			      Bytes.toBytes("jr .Software Engineer"));

			      p3.add(Bytes.toBytes("prof_details"),Bytes.toBytes("salary"),
			      Bytes.toBytes("90000"));
			      
			      // Saving the put Instance to the HTable.
			     hTable.put(p3);
			     
			      hTable.close();
			      
			      
			      System.out.println("data inserted");
			
			
			System.out.println(" Done!");
		}
	}
}
