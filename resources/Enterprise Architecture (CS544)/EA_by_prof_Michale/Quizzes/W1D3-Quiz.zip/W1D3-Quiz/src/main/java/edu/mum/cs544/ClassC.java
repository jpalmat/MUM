package edu.mum.cs544;

public class ClassC {
	public ClassC() { System.out.println("Class C constructor"); }
}