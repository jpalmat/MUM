package edu.mum.cs544;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Computer {
	@Id
	@GeneratedValue
	private Long id;
	@Column(name="cpu")
	private double CpuSpeed;
	private int ram;
	@ManyToOne
	private Person person;

	public Computer() {}

	public Computer(double cpuSpeed, int ram) {
		CpuSpeed = cpuSpeed;
		this.ram = ram;
	}
	
}