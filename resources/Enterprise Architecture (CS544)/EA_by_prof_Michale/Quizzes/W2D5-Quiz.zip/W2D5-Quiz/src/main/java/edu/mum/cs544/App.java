package edu.mum.cs544;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class App {
    private static EntityManagerFactory emf;

    public static void main(String[] args) {
        emf = Persistence.createEntityManagerFactory("cs544");
        		
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        PhoneNumber ph = new PhoneNumber("555-123-1234", "mobile");
        Person p = new Person("test", new Date(), ph);
        p.addComputer(new Desktop(4.2, 16, 2));
        em.persist(p);

        TypedQuery<Desktop> q = em.createQuery(
            "select d from Desktop d where d.person.phone.number like '555%'", Desktop.class);
        System.out.println(q.getResultList());

        em.getTransaction().commit();
        em.close();

    }
}