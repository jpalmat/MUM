package edu.mum.cs544;

import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class PhoneNumber {
	private String number;
	private String type;

	public PhoneNumber() {}

	public PhoneNumber(String number, String type) {
		this.number = number;
		this.type = type;
	}
	
}