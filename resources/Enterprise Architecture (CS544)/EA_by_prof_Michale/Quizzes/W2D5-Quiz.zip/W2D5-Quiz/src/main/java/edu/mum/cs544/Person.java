package edu.mum.cs544;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Data
@Entity
public class Person{
	@Id
	@GeneratedValue
	private Integer id;
	private String name;
	@Temporal(TemporalType.DATE)
	private Date birthDate;
	@Embedded
	private PhoneNumber phone;
	@OneToMany(mappedBy="person", cascade = CascadeType.ALL)
	//@JoinColumn
	private List<Computer> computers = new ArrayList<>();

	public Person() {}

	public Person(String name, Date birthDate, PhoneNumber number) {
		this.name = name;
		this.birthDate = birthDate;
		this.phone = number;
	}

	public void addComputer(Computer c) {
		computers.add(c);
		c.setPerson(this);
	}
	
}