package edu.mum.cs544;

import javax.persistence.Entity;

import lombok.Data;

@Data
@Entity
public class Laptop extends Computer {
	private double weight;
}