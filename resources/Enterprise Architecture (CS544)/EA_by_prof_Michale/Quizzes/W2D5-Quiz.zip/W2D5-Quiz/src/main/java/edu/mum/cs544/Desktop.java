package edu.mum.cs544;

import javax.persistence.Entity;

import lombok.Data;

@Data
@Entity
public class Desktop extends Computer {
	private int monitorCount;

	public Desktop() {}

	public Desktop(double cpu, int ram, int monitorCount) {
		super(cpu, ram);
		this.monitorCount = monitorCount;
	}

	
}