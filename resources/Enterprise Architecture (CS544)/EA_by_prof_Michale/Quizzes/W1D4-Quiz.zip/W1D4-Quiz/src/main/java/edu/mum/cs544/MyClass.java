package edu.mum.cs544;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyClass extends MySuper {
	@Autowired
	public MyClass(String text) {
		setText(text);
		System.out.println("MyClass Constructor");
	}
	public void sayHello() {
		System.out.println("This is a " + getText());
	}
}
