package edu.mum.cs544;

import javax.annotation.PostConstruct;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class TraceAspect {
	@Value("Test")
	private String text;

	public TraceAspect() {
		System.out.println("TraceAspect Constructor - text: " + text);
	}
	@PostConstruct
	public void start() {
		System.out.println("TraceAspect start method - text: " + text);
	}
	@Before("execution(* edu.mum.cs544.*.*(..))")
	public void beforeTrace(JoinPoint jp) {
		System.out.println("Before: " + jp.getSignature().getName());
		System.out.println(jp.getTarget().getClass().getSimpleName());
		Object[] args = jp.getArgs();
		if (args.length > 0) {
			System.out.println(jp.getArgs()[0]);
		}
	}
}
