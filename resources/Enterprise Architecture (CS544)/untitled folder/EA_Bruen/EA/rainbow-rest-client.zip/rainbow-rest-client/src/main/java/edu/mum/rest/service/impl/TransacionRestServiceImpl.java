package edu.mum.rest.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import edu.mum.rainbow.common.model.Client;
import edu.mum.rainbow.common.model.Transaction;
import edu.mum.rainbow.rest.RestHttpHeader;
import edu.mum.rainbow.rest.service.TransactionRestService;

@Component
public class TransacionRestServiceImpl implements TransactionRestService {

	@Autowired
	RestHttpHeader remoteApi;

	String baseUrl = "http://localhost:8080/rainbow-rest/tranx";
	
	@Override
	public List<Transaction> getClientTransactions(String clientNo) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
		List<Transaction> tranList = Arrays.asList(restTemplate.exchange(baseUrl+"/"+ clientNo, HttpMethod.GET, remoteApi.getHttpEntity(), Transaction[].class).getBody());
		return tranList;
	}
	
	
	@Override
	public Transaction save(Transaction tran) {
		RestTemplate restTemplate = remoteApi.getRestTemplate();
		HttpEntity<Transaction> httpEntity = new HttpEntity<Transaction>(tran, remoteApi.getHttpHeaders());
		restTemplate.exchange("http://localhost:8080/rainbow-rest/tranx/add/", HttpMethod.POST, httpEntity,Client.class);
		return null;
	}

	

}
