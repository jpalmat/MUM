package edu.mum.rest.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import edu.mum.rainbow.common.model.Client;
import edu.mum.rainbow.rest.RestHttpHeader;
import edu.mum.rainbow.rest.service.ClientRestService;

@Component
public class ClientRestServiceImpl implements ClientRestService {

	@Autowired
	RestHttpHeader restHttpHeader;

	String baseUrl = "http://localhost:8080/rainbow-rest/clients";
	
	@Override
	public List<Client> List() {
		RestTemplate restTemplate = restHttpHeader.getRestTemplate();
		HttpEntity httpEntity = new HttpEntity(restHttpHeader.getHttpHeaders());
		ResponseEntity<Client[]> responseEntity = restTemplate.exchange(baseUrl+"/all", HttpMethod.GET, httpEntity, Client[].class);	
 		List<Client> userList = Arrays.asList(responseEntity.getBody());
		return userList;
	}
	
	
	@Override
	public Client save(Client client) {
		RestTemplate restTemplate = restHttpHeader.getRestTemplate();
		HttpEntity<Client> httpEntity = new HttpEntity<Client>(client, restHttpHeader.getHttpHeaders());
		restTemplate.exchange(baseUrl+"/add", HttpMethod.POST, httpEntity,Client.class);
		return null;
	}

}
