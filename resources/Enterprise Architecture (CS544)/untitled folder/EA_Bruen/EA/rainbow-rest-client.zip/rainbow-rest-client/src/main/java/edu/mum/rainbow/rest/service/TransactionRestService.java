package edu.mum.rainbow.rest.service;

import java.util.List;

import org.springframework.stereotype.Component;

import edu.mum.rainbow.common.model.Transaction;

@Component
public interface TransactionRestService {

	public Transaction save(Transaction tran);

	public List<Transaction> getClientTransactions(String clientNo);
}
