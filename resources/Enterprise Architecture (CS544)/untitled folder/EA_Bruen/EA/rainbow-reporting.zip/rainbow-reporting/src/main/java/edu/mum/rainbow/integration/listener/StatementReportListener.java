package edu.mum.rainbow.integration.listener;

import edu.mum.rainbow.common.model.MonthlyStatment;

public class StatementReportListener {

	public void listen(MonthlyStatment monthlyStatment) {	
			
		System.out.println("AMQP Statement Report System: ");
		System.out.println("===========================================================");
		System.out.println("Client Name: " + monthlyStatment.getClientName());
		System.out.println("Account : " + monthlyStatment.getFullAccountNo());
		System.out.println("Total     : " + monthlyStatment.getTotalAmount());
		System.out.println("===========================================================");
	}
}
