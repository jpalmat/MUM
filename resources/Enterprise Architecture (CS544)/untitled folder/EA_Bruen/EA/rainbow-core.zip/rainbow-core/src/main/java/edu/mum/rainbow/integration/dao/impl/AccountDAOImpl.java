package edu.mum.rainbow.integration.dao.impl;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import edu.mum.rainbow.common.model.Account;
import edu.mum.rainbow.integration.dao.AccountDAO;

@Repository
public class AccountDAOImpl extends GenericDAOImpl<Account> implements AccountDAO{

	public AccountDAOImpl() {
		super.setDaoType(Account.class);
	}

	@Override
	public Account findByClient(String clientNo) {
		Query query = entityManager.createQuery("select acc from Account acc where acc.client.clientNo = :clientNo");
		return (Account)query.setParameter("clientNo", clientNo).getResultList().get(0);
	}

}
