package edu.mum.rainbow.integration.dao.impl;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import edu.mum.rainbow.common.model.UserCredentials;
import edu.mum.rainbow.integration.dao.CredentialsDAO;

@Repository
public class CredentialsDAOImpl extends GenericDAOImpl<UserCredentials> implements CredentialsDAO {

	public CredentialsDAOImpl() {
		super.setDaoType(UserCredentials.class);
	}

	@Override
	public UserCredentials getByUsername(String name) {
		Query query = entityManager.createQuery("select u from  CREDENTIALS u where u.username = :name");

		return (UserCredentials) query.setParameter("name", name).getSingleResult();

	}
}