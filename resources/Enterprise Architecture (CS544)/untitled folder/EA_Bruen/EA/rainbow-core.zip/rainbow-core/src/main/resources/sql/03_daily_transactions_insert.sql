INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-1001-001' , 50.30 , 'created' , 'amazon' , '2018-01-01', 1 , 1);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-1001-002' , 10.20 , 'created' , 'ebay' , '2018-01-01 05:13:08', 1 , 1);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-1001-003' , 30.15 , 'created' , 'BestBuy' , '2018-01-01 05:13:08', 1 , 1);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-1001-004' , 7.10 , 'created' , 'Walmart' , '2018-01-01 05:13:08', 1 , 1);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-1001-005' , 3.00 , 'created' , 'MAC' , '2018-01-01 05:13:08', 1 , 1);

INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-2002-001' , 50.30 , 'created' , 'amazon' , '2018-01-01', 2 , 2);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-2002-002' , 10.20 , 'created' , 'ebay' , '2018-01-01 05:13:08', 2 , 2);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-2002-003' , 30.15 , 'created' , 'BestBuy' , '2018-01-01 05:13:08', 2 , 2);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-2002-004' , 7.10 , 'created' , 'Walmart' , '2018-01-01 05:13:08', 2 , 2);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-2002-005' , 3.00 , 'created' , 'MAC' , '2018-01-01 05:13:08', 2 , 2);

INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-3003-001' , 50.30 , 'created' , 'amazon' , '2018-01-01', 3 , 3);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-3003-002' , 10.20 , 'created' , 'ebay' , '2018-01-01 05:13:08', 3 , 3);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-3001-003' , 30.15 , 'created' , 'BestBuy' , '2018-01-01 05:13:08', 3 , 3);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-3003-004' , 7.10 , 'created' , 'Walmart' , '2018-01-01 05:13:08', 3 , 3);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-3003-005' , 3.00 , 'created' , 'MAC' , '2018-01-01 05:13:08', 3 , 3);

INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-4004-001' , 50.30 , 'created' , 'amazon' , '2018-01-01', 4 , 4);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-4004-002' , 10.20 , 'created' , 'ebay' , '2018-01-01 05:13:08', 4 , 4);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-4004-003' , 30.15 , 'created' , 'BestBuy' , '2018-01-01 05:13:08', 4 , 4);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-4004-004' , 7.10 , 'created' , 'Walmart' , '2018-01-01 05:13:08', 4 , 4);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-4004-005' , 3.00 , 'created' , 'MAC' , '2018-01-01 05:13:08', 4 , 4);

INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-5005-001' , 50.30 , 'created' , 'amazon' , '2018-01-01', 5 , 5);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-5005-002' , 10.20 , 'created' , 'ebay' , '2018-01-01 05:13:08', 5 , 5);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-5005-003' , 30.15 , 'created' , 'BestBuy' , '2018-01-01 05:13:08', 5 , 5);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-5005-004' , 7.10 , 'created' , 'Walmart' , '2018-01-01 05:13:08', 5 , 5);
INSERT INTO DailyTransaction (tranId,amount,status,description,tranTime,accountId,clientId) VALUES( '20181217-5005-005' , 3.00 , 'created' , 'MAC' , '2018-01-01 05:13:08', 5 , 5);