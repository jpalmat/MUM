package edu.mum.rainbow.business.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.mum.rainbow.business.service.CredentialsService;
import edu.mum.rainbow.common.model.UserCredentials;
import edu.mum.rainbow.integration.dao.CredentialsDAO;

@Service
@Transactional
public class CredentialsServiceImpl implements CredentialsService {

	@Autowired
	private CredentialsDAO credentialsDAO;

//  	@PreAuthorize("hasRole('ADMIN')")
	public void save(UserCredentials credentials) {

		PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(credentials.getPassword());
		credentials.setPassword(encodedPassword);

		credentialsDAO.save(credentials);
	}

	public List<UserCredentials> findAll() {
		return (List<UserCredentials>) credentialsDAO.findAll();
	}

	public UserCredentials getByUsername(String name) {
		return credentialsDAO.getByUsername(name);
	}

}
