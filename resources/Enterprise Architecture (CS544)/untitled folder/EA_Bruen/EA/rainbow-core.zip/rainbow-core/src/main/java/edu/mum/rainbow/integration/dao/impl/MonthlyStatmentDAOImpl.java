package edu.mum.rainbow.integration.dao.impl;

import org.springframework.stereotype.Repository;

import edu.mum.rainbow.common.model.MonthlyStatment;
import edu.mum.rainbow.integration.dao.MonthlyStatmentDAO;

@Repository
public class MonthlyStatmentDAOImpl extends GenericDAOImpl<MonthlyStatment> implements MonthlyStatmentDAO{

	public MonthlyStatmentDAOImpl() {
		super.setDaoType(MonthlyStatment.class);
	}
}
