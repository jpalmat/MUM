drop database rainbow;
create database rainbow;