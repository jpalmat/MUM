package edu.mum.rainbow.business.batch.daily;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.mum.rainbow.business.service.TransactionService;
import edu.mum.rainbow.common.model.Transaction;

@Component
public class DailyTransactionBatchWriter implements ItemWriter<Transaction> {

	@Autowired
	private TransactionService transactionService;

	@Override
	public void write(List<? extends Transaction> transactions) throws Exception {
		for (Transaction tran : transactions) {
			if( tran.getPostingTime()!=null) {
				this.transactionService.createTransaction(tran);
			}
			
		}
	}
}
