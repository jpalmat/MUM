 
package edu.mum.rainbow.integration.transformer;

import org.springframework.integration.annotation.Transformer;

import edu.mum.rainbow.common.model.MonthlyStatment;

/**
 * Routes order based on order type.
 * 
 */
public class StatementTransformerImpl implements StatementTransformer {

     /**
     * Transform Order from AMQP to RouteOrder for JMS
      */
	@Transformer(inputChannel="fromAmqpOrder", outputChannel="processOrder")
	public MonthlyStatment transformOrder(MonthlyStatment monthlyStatment) {
		return monthlyStatment;
	}

}
