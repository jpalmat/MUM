 
package edu.mum.rainbow.integration.transformer;

import edu.mum.rainbow.common.model.MonthlyStatment;

/**
 * Routes order based on order type.
 * 
 */

public interface StatementTransformer {

	public MonthlyStatment transformOrder(MonthlyStatment statment);

}
