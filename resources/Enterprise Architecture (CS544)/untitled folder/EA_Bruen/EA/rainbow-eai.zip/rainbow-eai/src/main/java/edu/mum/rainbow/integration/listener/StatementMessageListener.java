package edu.mum.rainbow.integration.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import edu.mum.rainbow.common.model.MonthlyStatment;


public class StatementMessageListener implements MessageListener {
    private static final Logger logger = LoggerFactory.getLogger(StatementMessageListener.class);

    public void onMessage(Message message) {
        ObjectMessage objectMessage = (ObjectMessage) message;
        MonthlyStatment statement = null;
		try {
			statement = (MonthlyStatment) objectMessage.getObject();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println("Message received: " );
        System.out.println("         Statement: "  +  statement);

    }
}
