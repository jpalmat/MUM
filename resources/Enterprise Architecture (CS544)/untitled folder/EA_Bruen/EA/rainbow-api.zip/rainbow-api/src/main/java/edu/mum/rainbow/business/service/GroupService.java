package edu.mum.rainbow.business.service;

import java.util.List;

import edu.mum.rainbow.common.model.Grooups;
 
public interface GroupService {

	public void save(Grooups group);
	public Grooups update(Grooups group);
	public List<Grooups> findAll();
 }
