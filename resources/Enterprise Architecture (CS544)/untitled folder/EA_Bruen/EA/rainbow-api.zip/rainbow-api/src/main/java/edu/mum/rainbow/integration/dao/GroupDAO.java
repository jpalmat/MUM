package edu.mum.rainbow.integration.dao;

import edu.mum.rainbow.common.model.Grooups;

public interface GroupDAO extends GenericDAO<Grooups> {

}
