package edu.mum.rainbow.integration.dao;

import edu.mum.rainbow.common.model.Account;

public interface AccountDAO extends GenericDAO<Account>{

	public Account findByClient(String clientNo);
}
