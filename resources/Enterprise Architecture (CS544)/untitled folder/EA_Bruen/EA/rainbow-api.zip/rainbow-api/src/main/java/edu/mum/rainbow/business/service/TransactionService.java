package edu.mum.rainbow.business.service;

import java.util.List;

import edu.mum.rainbow.common.model.DailyTransaction;
import edu.mum.rainbow.common.model.Transaction;

public interface TransactionService {

	Transaction transferDailyToHistoricalTransaction(DailyTransaction dailyTransaction);

	Transaction createTransaction(Transaction tran);

	List<Transaction> fetchTransactionsByClient(String clientNo);

}
