package edu.mum.rainbow.business.service;

public interface SampleBusinessService {

}
