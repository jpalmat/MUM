
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Vector;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Rizk
 */
public class RoundRobinAlgorithm {

    public static Results Run(int runtime, Vector processVector, Results result) {
        int i = 0;
        int comptime = 0;
        int currentProcess = 0;
        int size = processVector.size();
        int completed = 0;
        String resultsFile = "Summary-Processes";
        int quantum = 60;
        int quantumRemain = quantum;

        result.schedulingType = "Interactive (Preemptive)";
        result.schedulingName = "Round-Robin";
        try {
            PrintStream out = new PrintStream(new FileOutputStream(resultsFile));
            sProcess process = (sProcess) processVector.elementAt(currentProcess);
            out.println("Process: " + currentProcess + " registered... (" + process.cputime + " " + process.ioblocking + " " + process.cpudone + " " + process.cpudone + ")");
            while (comptime < runtime) {
                if (process.cpudone == process.cputime) {
                    completed++;
                    out.println("Process: " + currentProcess + " completed... (" + process.cputime + " " + process.ioblocking + " " + process.cpudone + " " + process.cpudone + ")");
                    if (completed == size) {
                        result.compuTime = comptime;
                        out.close();
                        return result;
                    }

                    currentProcess = contextSwitch(processVector, currentProcess);

                    process = (sProcess) processVector.elementAt(currentProcess);
                    out.println("Process: " + currentProcess + " registered... (" + process.cputime + " " + process.ioblocking + " " + process.cpudone + " " + process.cpudone + ")");
                    quantumRemain = quantum;
                }
                if (process.ioblocking == process.ionext || quantumRemain == 0) {
                    if (quantumRemain == 0) {
                        out.println("Context Switch, Process completed its quantum");                 
                    }
                    
                    if (process.ioblocking == process.ionext) {
                        out.println("Process: " + currentProcess + " I/O blocked... (" + process.cputime + " " + process.ioblocking + " " + process.cpudone + " " + process.cpudone + ")");
                        process.numblocked++;
                        process.ionext = 0;
                    }
                    
                    quantumRemain = quantum;
                    currentProcess = contextSwitch(processVector, currentProcess);
                    process = (sProcess) processVector.elementAt(currentProcess);
                    out.println("Process: " + currentProcess + " registered... (" + process.cputime + " " + process.ioblocking + " " + process.cpudone + " " + process.cpudone + ")");
                }
                process.cpudone++;
                if (process.ioblocking > 0) {
                    process.ionext++;
                }
                comptime++;
                quantumRemain--;
            }
            out.close();
        } catch (IOException e) { /* Handle exceptions */ }
        result.compuTime = comptime;
        return result;
    }

    public static int contextSwitch(Vector processVector, int currentProcess) {
        sProcess process = null;
        for (int i = 0; i < processVector.size(); i++) {
            currentProcess = (currentProcess + 1) % processVector.size();
            process = (sProcess) processVector.elementAt(currentProcess);

            if (process.cpudone < process.cputime) {
                break;
            }
        }

        return currentProcess;
    }
}
