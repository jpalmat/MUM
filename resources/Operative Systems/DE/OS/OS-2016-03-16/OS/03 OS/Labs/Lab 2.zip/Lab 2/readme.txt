Mohamed Metwally
983692

Answers:
1. 3.a --> answer of the first question is First-in First-out (FIFO). Attached commands, config files and trace file.
2. Attached PageFault (Round-Robin).
3. Attached PageFault (LRU).