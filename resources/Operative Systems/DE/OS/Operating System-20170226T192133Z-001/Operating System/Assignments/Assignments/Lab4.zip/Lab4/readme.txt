1. Try running the deadlock simulator using the following command: java deadlock a 2 2 
Explain why a deadlock does not occur.
Answer:
Given is
java deadlock a 2 2

where,
a is the prefix for the names of the files containing the commands, (the actual names of the files are "a0.dat", and "a1.dat"),
2 is the number of processes to be created,
2 is the number of instances to create for the first resource.

Following are the output at console when I run "java deadlock a 2 1" command and "java deadlock a 2 2".


D:\MUM\OS\Lab4>java deadlock a 2 1
time = 0 available = 1 blocked = 0
time = 1 available = 1 blocked = 0
time = 2 available = 1 blocked = 0
time = 3 available = 1 blocked = 0
time = 4 available = 1 blocked = 0
time = 5 available = 1 blocked = 0
time = 6 available = 1 blocked = 0
time = 7 available = 1 blocked = 0
time = 8 available = 1 blocked = 0
time = 9 available = 1 blocked = 0
time = 10 available = 0 blocked = 1
time = 11 available = 0 blocked = 1
time = 12 available = 0 blocked = 1
time = 13 available = 0 blocked = 1
time = 14 available = 0 blocked = 1
time = 15 available = 0 blocked = 1
time = 16 available = 0 blocked = 1
time = 17 available = 0 blocked = 1
time = 18 available = 0 blocked = 1

D:\MUM\OS\Lab 4>java deadlock a 2 2
time = 0 available = 2 blocked = 0
time = 1 available = 2 blocked = 0
time = 2 available = 2 blocked = 0
time = 3 available = 2 blocked = 0
time = 4 available = 2 blocked = 0
time = 5 available = 2 blocked = 0
time = 6 available = 2 blocked = 0
time = 7 available = 2 blocked = 0
time = 8 available = 2 blocked = 0
time = 9 available = 2 blocked = 0
time = 10 available = 0 blocked = 0
time = 11 available = 0 blocked = 0
time = 12 available = 0 blocked = 0
time = 13 available = 0 blocked = 0
time = 14 available = 0 blocked = 0
time = 15 available = 0 blocked = 0
time = 16 available = 0 blocked = 0
time = 17 available = 0 blocked = 0
time = 18 available = 0 blocked = 0
time = 19 available = 0 blocked = 0
time = 20 available = 2 blocked = 0

This illustrate how deadlock occurs and how available resources are shown.




2. There are two additional process command files ("b0.dat" and "b1.dat") in the distribution. Run the deadlock simulator with this command:
java deadlock b 2 1 1
What happens? Now try this.
java deadlock b 2 1 2
Why does the first command result in a deadlock but the second does not? Explain your answer in terms of what is going on in the process command files, b0.dat and b1.dat.

Answer:
When I ran following comman
java deadlock b 2 1 1
We get following output:

D:\MUM\OS\Lab 4>java deadlock b 2 1 1
time = 0 available = 1 1 blocked = 0
time = 1 available = 1 1 blocked = 0
time = 2 available = 1 1 blocked = 0
time = 3 available = 1 1 blocked = 0
time = 4 available = 1 1 blocked = 0
time = 5 available = 1 1 blocked = 0
time = 6 available = 1 1 blocked = 0
time = 7 available = 1 1 blocked = 0
time = 8 available = 1 1 blocked = 0
time = 9 available = 1 1 blocked = 0
time = 10 available = 0 0 blocked = 0
time = 11 available = 0 0 blocked = 0
time = 12 available = 0 0 blocked = 0
time = 13 available = 0 0 blocked = 0
time = 14 available = 0 0 blocked = 0
time = 15 available = 0 0 blocked = 0
time = 16 available = 0 0 blocked = 0
time = 17 available = 0 0 blocked = 0
time = 18 available = 0 0 blocked = 0
time = 19 available = 0 0 blocked = 0
time = 20 available = 0 0 blocked = 2

It shows that the deadlocks is occured at the end of the processes.

Similarly when I ran following command:
java deadlock b 2 1 2

We got the following output:


D:\MUM\OS\Lab4>java deadlock b 2 1 2
time = 0 available = 1 2 blocked = 0
time = 1 available = 1 2 blocked = 0
time = 2 available = 1 2 blocked = 0
time = 3 available = 1 2 blocked = 0
time = 4 available = 1 2 blocked = 0
time = 5 available = 1 2 blocked = 0
time = 6 available = 1 2 blocked = 0
time = 7 available = 1 2 blocked = 0
time = 8 available = 1 2 blocked = 0
time = 9 available = 1 2 blocked = 0
time = 10 available = 0 1 blocked = 0
time = 11 available = 0 1 blocked = 0
time = 12 available = 0 1 blocked = 0
time = 13 available = 0 1 blocked = 0
time = 14 available = 0 1 blocked = 0
time = 15 available = 0 1 blocked = 0
time = 16 available = 0 1 blocked = 0
time = 17 available = 0 1 blocked = 0
time = 18 available = 0 1 blocked = 0
time = 19 available = 0 1 blocked = 0
time = 20 available = 0 0 blocked = 1
time = 21 available = 0 0 blocked = 1
time = 22 available = 0 0 blocked = 1
time = 23 available = 0 0 blocked = 1
time = 24 available = 0 0 blocked = 1
time = 25 available = 0 0 blocked = 1
time = 26 available = 0 0 blocked = 1
time = 27 available = 0 0 blocked = 1
time = 28 available = 0 0 blocked = 1
time = 29 available = 0 0 blocked = 1
time = 30 available = 0 1 blocked = 0
time = 31 available = 0 1 blocked = 0
time = 32 available = 0 1 blocked = 0
time = 33 available = 0 1 blocked = 0
time = 34 available = 0 1 blocked = 0
time = 35 available = 0 1 blocked = 0
time = 36 available = 0 1 blocked = 0
time = 37 available = 0 1 blocked = 0
time = 38 available = 0 1 blocked = 0
time = 39 available = 0 1 blocked = 0
time = 40 available = 1 2 blocked = 0

In b1.dat, after 10 millisecond the resources gets free as the requested resources after ten milisecond is R=0 as given in the b1.dat

C 10    // compute for 10 milliseconds
R 1     // request resource 1
C 10    // compute for 10 milliseconds
R 0     // request resource 0
C 10    // compute for 10 milliseconds
F 0     // free resource 0
F 1     // free resource 1
H       // halt process

Thus no deadlock is occured in the b1.dat


