When I run the following command in the command prompt
java mkfs rupaknepali.dat 64 8
Then I got following output and it makes rupaknepali.dat file where i installed filesys.exe.

OUTPUT
block_size: 64
blocks: 8
super_blocks: 1
free_list_blocks: 1
inode_blocks: 3
data_blocks: 3
block_total: 8

There is 1 block for free list management because that 3 blocks require 3 bits in the free list bitmap. Since 64bytes/block * 8 bits/byte = 512 bits/block, clearly one bitmap block is sufficient to track block allocation for this file system.

There are 8 blocks for index nodes because that 8 blocks could result in 8 inodes if many one-block files or directories are created. Since each inode requires 64 bytes, only 4 will fit in a block. Therefore, 8 blocks are set aside for up to 32 inodes.

Then I ran another command as follows:
java dum[ rupaknepali.dat
I got following output

1 40 64 @
5 8 8
9 1 1
13 2 2
17 5 5
64 1 1
128 40 64 @
131 3 3
139 20 32
143 ff 255
144 ff 255
145 ff 255
146 ff 255
147 ff 255
148 ff 255
149 ff 255
150 ff 255
151 ff 255
152 ff 255
153 ff 255
154 ff 255
155 ff 255
156 ff 255
157 ff 255
158 ff 255
159 ff 255
160 ff 255
161 ff 255
162 ff 255
163 ff 255
164 ff 255
165 ff 255
166 ff 255
167 ff 255
168 ff 255
169 ff 255
322 2e 46 .
338 2e 46 .
339 2e 46 .

64 is at the third position so it is the decimal value of the byte as the general format of the dump output is addr hex dec asc.

Then I run following command
java mkdir D:/Mum/OS/rupak

where D:/Mum/OS/ are the root directory file and rupak folder is created. After that we are not able to create another folder which is showing Kernal: unable to open root file system.
This shows we are no more able to create the folder. We are able to create only one folder.
