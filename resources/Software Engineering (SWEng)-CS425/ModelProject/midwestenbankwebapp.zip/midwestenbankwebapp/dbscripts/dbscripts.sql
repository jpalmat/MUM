-- CREATE DATABASE `midwestenbankdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

CREATE SCHEMA `midwestenbankdb` ;

insert into midwestenbankdb.accounttypes (accounttypename) values ('Checking');
insert into midwestenbankdb.accounttypes (accounttypename) values ('Loan');
insert into midwestenbankdb.accounttypes (accounttypename) values ('Savings');

