package edu.mum.cs.cs425.finalexam.midwestenbankwebapp.service;

import edu.mum.cs.cs425.finalexam.midwestenbankwebapp.model.AccountType;

import java.util.List;

public interface IAccountTypeService {

    public List<AccountType> getAllAccountTypes();
}
