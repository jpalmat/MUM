package counter;

public interface IFrameObserver {
    void update(Counter counter);
}
