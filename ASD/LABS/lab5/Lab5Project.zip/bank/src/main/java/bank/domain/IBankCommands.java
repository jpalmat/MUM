package bank.domain;

public interface IBankCommands {
    void execute();
    void unexecute();
}
