package bank.domain;

public class MethodLogger {
    public void log(String message){
        System.out.println(message);
    }
}
