package with.proxy;

public interface CustomerDAO {
	Customer findCustomerById(int customerId);
}
