package with.dynamicproxy;

public interface CustomerDAO {
	Customer findCustomerById(int customerId);
}
