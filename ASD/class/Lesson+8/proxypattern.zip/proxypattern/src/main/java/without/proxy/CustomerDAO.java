package without.proxy;

public interface CustomerDAO {
	Customer getCustomer(int customerId);
}
